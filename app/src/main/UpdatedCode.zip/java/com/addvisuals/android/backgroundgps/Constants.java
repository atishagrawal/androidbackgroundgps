package com.addvisuals.android.backgroundgps;

public class Constants {

    public static final String SECRET_KEY = "GEHHdhLwHX_XBPTApnTp8VA@zY?9ZSQR";
    public static final String TRACK_URL = "https://emmabackgroundgps.000webhostapp.com/WebAPI.php";
    public Constants() {
        // TODO Auto-generated constructor stub
    }

}
